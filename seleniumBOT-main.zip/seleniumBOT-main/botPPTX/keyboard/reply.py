from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

# remKB = ReplyKeyboardRemove()

main_page = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Профиль"), KeyboardButton(text="История")],
        [KeyboardButton(text="Создать презентацию")],
        [KeyboardButton(text="Помощь")],
    ],
    resize_keyboard=True,
    # one_time_keyboard=True,
    input_field_placeholder="◯ Главная страница ◯",
)

add_balance = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Пополнить баланс")],
        [KeyboardButton(text="Главная")],
    ],
    resize_keyboard=True,
    # one_time_keyboard=True,
    input_field_placeholder="◯ Пополнить баланс для покупки ◯",
)
