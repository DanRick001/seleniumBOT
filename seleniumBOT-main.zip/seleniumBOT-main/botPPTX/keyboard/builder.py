import asyncio
from aiogram.utils.keyboard import InlineKeyboardBuilder

max_presentaion_pages = 10


async def count_pages_kb():
    done_keyboard = InlineKeyboardBuilder()
    for page in range(1, max_presentaion_pages + 1):
        done_keyboard.button(text=str(page), callback_data=f"pickedCountPages_{page}")
    return done_keyboard.as_markup(resize_keyboard=True)


async def cancel_get_presentation_name():
    done_keyboard = InlineKeyboardBuilder()
    done_keyboard.button(text="Отменить", callback_data=f"cancelPickedCountPages")
    return done_keyboard.as_markup(resize_keyboard=True)
