TOKEN = "5482359138:AAG4948wIiaLLn8fZV0624LYTdu5kCkXGIc"
PARSE_MODE = "HTML"
IS_DEBUG = False
ADMIN_ID = [1194880448]
DOWNLOAD_PATH = "./downloaded_files/"
LOGIN = "maruncov97@gmail.com"
PASSWORD = "321qwesdfxcv123F!"

# https://api.telegram.org/bot5482359138:AAG4948wIiaLLn8fZV0624LYTdu5kCkXGIc/sendMessage?chat_id=1194880448&text=234&parse_mode=HTML
