import sqlite3
import os
import asyncio
from datetime import datetime

db = sqlite3.connect("mainBase.db")
cursor = db.cursor()

cursor.execute(
    """CREATE TABLE IF NOT EXISTS data(
        user_id INTEGER,
        balance INTEGER
    )"""
)

db.commit()


async def isRegister(user_id: int):
    cursor.execute("SELECT user_id FROM data WHERE user_id = ?", (user_id,))
    result = cursor.fetchone()
    if result:
        return True
    else:
        return False


async def getData(user_id: int):
    cursor.execute("SELECT * FROM data WHERE user_id = ?", (user_id,))
    data = cursor.fetchone()

    # user_id = data[0]
    balance = data[1]

    print(f"parsed base: {user_id}")
    return [balance]


async def register(user_id: int):
    cursor.execute(f"SELECT user_id FROM data WHERE user_id = '{user_id}'")
    cursor.execute(
        f"INSERT INTO data VALUES (?, ?)",
        (user_id, 3),
    )
    db.commit()


async def balance(
    user_id: int,
    pay_cost: int,
):
    data = await getData(user_id)
    new_balance = data[0] + pay_cost
    cursor.execute(
        "UPDATE data SET balance = ? WHERE user_id = ?", (new_balance, user_id)
    )

    db.commit()
    print(f"new balance at: {user_id} is: {new_balance}")


async def marry_past_day(user_id):
    data = await get_data(user_id)
    marry_date = datetime.strptime(data[4], "%Y-%m-%d")
    now_date = datetime.now()
    return (now_date - marry_date).days


async def change_gender(user_id: int, gender: str):
    data = await get_data(user_id)
    if data != False:
        cursor.execute(
            "UPDATE data SET gender = ? WHERE user_id = ?", (gender, user_id)
        )
    else:
        return False
