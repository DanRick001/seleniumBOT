from generation.uc_driver import queue_handler
import asyncio
from aiogram import Dispatcher, types, F
from aiogram.types import Message
from aiogram.filters import Command, CommandObject, StateFilter, or_f
from aiogram.filters.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from keyboard import builder, reply

from config import TOKEN, PARSE_MODE
from aiogram import Bot


from database import sql
from time import sleep


# while
# sleep(100)
# loop = asyncio.get_event_loop()
bot = Bot(TOKEN, parse_mode=PARSE_MODE)
# dp = Dispatcher(loop=loop)
dp = Dispatcher()
# driver = ChromeDriver("./generation/chromedriver.exe")


class Page(StatesGroup):
    presentation_get_name = State()
    generate_file = State()


async def user_link(user_id: int, user_name: str):
    return hlink(user_name, f"tg://user?id={user_id}")


async def admin_msg(msg: str):
    for admin in ADMIN_ID:
        await bot.send_message(chat_id=admin, text=msg)


@dp.message(StateFilter(None), Command(commands=["start", "старт"]))
async def start(message: Message):
    user_id = message.from_user.id
    isRegister = await sql.isRegister(user_id)
    if isRegister == False:
        print(f"new user: {user_id}")
        await sql.register(user_id)
        await message.reply(text="Регистрация успешна!", reply_markup=reply.main_page)
    else:
        await message.reply(text="Вы уже зареганы!", reply_markup=reply.main_page)


@dp.message(
    StateFilter(None),
    or_f(Command(commands=["balance"]), F.text.lower() == "пополнить баланс"),
)
async def payBalance(message: Message):
    user_id = message.from_user.id
    isRegister = await sql.isRegister(user_id)
    if isRegister == True:
        await message.reply(text="Обработка пополнения...")


async def profileBuilder(user_id: int):
    data = await sql.getData(user_id=user_id)
    msg = f"Айди: {user_id}\nБаланс: {data[0]}"
    return msg


@dp.message(
    StateFilter(None),
    or_f(
        Command(commands=["profile", "main"]),
        F.text.lower() == "профиль",
        F.text.lower() == "главная",
    ),
)
async def profilePage(message: Message, state: FSMContext):
    user_id = message.from_user.id
    isRegister = await sql.isRegister(user_id)
    if isRegister == True:
        await message.reply(
            text=await profileBuilder(user_id), reply_markup=reply.main_page
        )


@dp.message(StateFilter(None), F.text.lower() == "создать презентацию")
async def generatePage(message: Message, state: FSMContext):
    user_id = message.from_user.id
    isRegister = await sql.isRegister(user_id)
    if isRegister == True:
        data = await sql.getData(user_id)
        if data[0] > 0:
            await message.reply(
                text="Теперь максимально подробно опишите презентацию.\nОзнакомиться с вариантами описания ->",
                reply_markup=await builder.cancel_get_presentation_name(),
            )
            await state.set_state(Page.presentation_get_name)
        else:
            await message.reply(
                text="Вам не хватает баланса! Чтобы пополнить /balance",
                reply_markup=reply.add_balance,
            )


@dp.message(Page.presentation_get_name)
async def getDescription(message: Message, state: FSMContext):
    await state.update_data(presentation_name=message.text)
    await message.answer(
        text="Теперь укажите кол-во слайдов: ",
        reply_markup=await builder.count_pages_kb(),
    )
    # await state.update_data(isGenerating=False)
    await state.set_state(Page.generate_file)


@dp.callback_query(F.data.startswith("cancelPickedCountPages"))
async def callback_picked_count_page(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    await callback.message.reply(
        text=await profileBuilder(user_id), reply_markup=reply.main_page
    )
    await state.clear()
    await callback.answer()


@dp.callback_query(Page.generate_file, F.data.startswith("pickedCountPages_"))
async def callback_picked_count_page(callback: types.CallbackQuery, state: FSMContext):
    action = callback.data.split("_")
    user_id = callback.from_user.id
    user_data = await state.get_data()
    print(action, user_id, user_data["presentat	ion_name"])
    message_id = callback.message.message_id
    pay_cost = -1
    asyncio.ensure_future(
        queue_handler(
            user_id=user_id,
            bot=bot,
            message_id=message_id,
            data=[user_data["presentation_name"], action],
            state=state,
            pay_cost=pay_cost,
        )
    )

    await callback.answer()


async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
