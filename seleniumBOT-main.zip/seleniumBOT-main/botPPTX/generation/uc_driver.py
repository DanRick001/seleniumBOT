import os, asyncio
from threading import Thread

from aiogram.fsm.context import FSMContext
from aiogram.types import FSInputFile
from aiogram.utils.markdown import hlink
from database import sql
from config import IS_DEBUG, DOWNLOAD_PATH, LOGIN, PASSWORD

from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from time import sleep
from shutil import move as moveTo_

queue = []
generation_result = [False]


async def start_generation(user_id: int, data: list):
    global driver
    if not os.path.exists(f"./files/{user_id}"):
        os.mkdir(f"./files/{user_id}")
    # driver.generation_file(data[0])
    thread = Thread(target=driver.generation_file, args=(data[0],))
    thread.start()
    while thread.is_alive():
        await asyncio.sleep(5)

    print(f"Закончил генерацию: {generation_result[0]}")
    return generation_result[0]


async def queue_handler(
    user_id: int,
    bot,
    message_id: int,
    data: list,
    state: FSMContext,
    pay_cost: int,
):
    global queue
    queue.append(user_id)
    last_position = 0
    while len(queue) > 1:
        await asyncio.sleep(1)  # Проверка значения каждую секунду
        position = queue.index(user_id)
        if position != last_position:
            await bot.edit_message_text(
                chat_id=user_id,
                message_id=message_id,
                text=f"Ожидание... Очередь: {position}",
            )
            last_position = position

    await bot.edit_message_text(
        chat_id=user_id, message_id=message_id, text=f"Генерация..."
    )

    gen_result = await start_generation(user_id, data)
    if gen_result == True:
        await sql.balance(user_id=user_id, pay_cost=pay_cost)
        await bot.edit_message_text(
            chat_id=user_id,
            message_id=message_id,
            text=f"Готова презентация на тему: {data[0]}",
        )
        print(f"Готова презентация на тему: {data[0]}")

        directory = await get_download_file_path(user_id=user_id)
        if directory != False:
            await bot.send_document(chat_id=user_id, document=FSInputFile(directory))
        else:
            await bot.edit_message_text(
                chat_id=user_id,
                message_id=message_id,
                text=f"Произошла ошибка! Уже разбираемся!",
            )

            print(f"Ошибка:\nИмя: {user_id}\nОшибка: {gen_result}")

    else:
        await bot.edit_message_text(
            chat_id=user_id,
            message_id=message_id,
            text=f"Произошла ошибка! Уже разбираемся!",
        )

        print(f"Ошибка:\nИмя: {user_id}\nОшибка: {gen_result}")

    queue.remove(user_id)
    await state.clear()


async def get_download_file_path(user_id: int):
    directory = DOWNLOAD_PATH
    files_list = os.listdir(directory)
    for file in files_list:
        if file != "driver_fixing.lock":
            directory += file
            new_dir = f"./files/{user_id}/{file}"
            moveTo_(directory, new_dir)
            # rename random
            return new_dir
    return False


class ChromeDriver:
    def __init__(self):
        self.driver = Driver(uc=True, headed=True, devtools=True,no_sandbox=True,headless2=False)
        #self.driver.maximize_window()
        self.driver.set_window_size(1920,1080,self.driver.window_handles[0])
        print("Succeses load browser")

    def bypass_cloudflare(self):
        url = "https://gamma.app/signin"
        self.driver.execute_script(f"window.open('{url}', '_blank')")
        #self.driver.open(url)
        print("загружаю сайт")
        sleep(5)
        self.driver.switch_to.window(self.driver.window_handles[1])
        #self.driver.save_screenshot("test1.png")
        sleep(5)
        #self.driver.save_screenshot("test2.png")
        try:
            captcha_xpath = ".//iframe"
            captcha_frame = self.driver.find_element(By.XPATH, captcha_xpath)
            print(f"обхожу защиту: {captcha_frame}")
            self.driver.switch_to.frame(captcha_frame)
            captcha_label = self.driver.find_element(
                By.XPATH, '//*[@id="challenge-stage"]/div/label/input'
            )
            captcha_label.click()
            print("обнaружена каптча")
            #sleep(10)
            sleep(10)
        except NoSuchElementException as ex:
            print(f"каптчи нет")

        return True

    def login(self, login: str, password: str):
        response = self.bypass_cloudflare()
        print(f"bypass_cloudflare: {response}")
        if response == True:
            try:
                self.driver.switch_to.window(self.driver.window_handles[1])
                login_input = self.driver.find_element(By.XPATH, '//*[@id="email"]')
                # login_input = self.driver.find_element(By.ID, "email")
                login_input.send_keys(login)

                password_input = self.driver.find_element(
                    By.XPATH, '//*[@id="password"]'
                )
                password_input.send_keys(password)
                login_btn = self.driver.find_element(
                    By.XPATH,
                    '//*[@id="__next"]/div[2]/div[1]/div/div/div/div/form/div/div[5]/button',
                )  # ненадёжно
                login_btn.click()
                try:
                    print("обнаружена каптча")
                    captcha_xpath = ".//iframe[@title='reCAPTCHA']"
                    captcha_frame = self.driver.find_element(By.XPATH, captcha_xpath)
                    self.driver.switch_to.frame(captcha_frame)
                    captcha_label = self.driver.find_element(By.ID, "recaptcha-anchor-label")
                    captcha_label.click()
                    sleep(10)
                    # self.driver.refresh()
                except NoSuchElementException as ex:
                    print(f"каптчи нет")
                print("вроде вошёл")
                return True
            except Exception as ex:
                print(ex)
        else:
            return False

    def generation_file(self, theme: str):
        global generation_result
        try:
            # self.driver.close()
            # sleep(1)
            # self.driver.execute_script(f"window.open('https://gamma.app/', '_blank')")
            print("загружаю сайт")
            sleep(5)
            self.driver.switch_to.window(self.driver.window_handles[1])
            sleep(3)
            pre_generate_btn = self.driver.find_element(
                By.CLASS_NAME,
                "css-5zijnz",
            )
            pre_generate_btn.click()

            sleep(3)

            generate_btn = self.driver.find_element(
                By.XPATH,
                '//*[@id="main"]/div/div[2]/div[2]/div[2]/div/div/div/div[2]/button',
            )
            generate_btn.click()

            sleep(3)

            theme_input = self.driver.find_element(
                By.XPATH,
                '//*[@id="main"]/div/div[2]/div[3]/div[1]/div[2]/div/div[2]/input',
            )
            theme_input.send_keys(theme)

            """await asyncio.sleep(3)

            theme_input = self.driver.find_element(
                By.XPATH, '//*[@id="menu-button-:rq:"]'
            )
            theme_input.click()

            await asyncio.sleep(3)

            theme_input = self.driver.find_element(
                By.XPATH, '//*[@id="menu-list-:rq:-menuitem-:r34:"]'
            )
            theme_input.click()"""

            sleep(3)

            finally_generate = self.driver.find_element(
                By.XPATH,
                '//*[@id="main"]/div/div[2]/div[3]/div[1]/div[2]/div/div[4]/div/button',
            )
            finally_generate.click()

            sleep(7)

            last_generate_btn = self.driver.find_element(
                By.XPATH,
                '//*[@id="main"]/div/div[2]/div[4]/div/div[2]/div/div[2]/span/button',
            )
            last_generate_btn.click()

            sleep(3)

            theme_selection = self.driver.find_element(
                By.XPATH,
                '//*[@id="main"]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div[1]/div/div[2]/div/button[1]',
            )
            theme_selection.click()

            # while 1:
            sleep(40)
            self.driver.switch_to.window(self.driver.window_handles[1])

            export_btn = self.driver.find_elements(
                By.CLASS_NAME, "chakra-menu__menu-button"
            )[1]
            export_btn.click()

            sleep(3)

            export_btn = self.driver.find_elements(
                By.CLASS_NAME, "chakra-menu__menuitem"
            )[20]
            export_btn.click()

            sleep(3)

            export_1 = self.driver.find_elements(By.CLASS_NAME, "chakra-modal__body")[0]
            export_2 = export_1.find_elements(By.CLASS_NAME, "chakra-stack")[1]
            export_3 = export_2.find_elements(By.CLASS_NAME, "chakra-stack")[0]
            export_3.find_elements(By.CSS_SELECTOR, "button")[1].click()
            while 1:
                sleep(5)
                try:
                    site_alert = self.driver.find_elements(
                        By.CLASS_NAME, "chakra-alert"
                    )[0].get_attribute("data-status")
                    if site_alert == "success":
                        print("успешно!")
                        generation_result[0] = True
                        break
                except NoSuchElementException as ex:
                    print("ожидание ссылки для скаживания")

        except Exception as ex:
            print(f"Ошибка: {ex}")
            generation_result[0] = ex


driver = ChromeDriver()
driver.login(login=LOGIN, password=PASSWORD)

# login(login="maruncov98@mail.ru", password="321qwesdfxcv123F!")
# threading.Thread(target=driver.login, args=("maruncov98@mail.ru", "321qwesdfxcv123F!")).start()
if IS_DEBUG == True:
    print("loading in debug mode")
# else:
# driver.load_cookie(SESSION_PATH)
while IS_DEBUG == True:
    concole = input("enter command:")
    if "/open" in concole:
        driver.open_page(url=concole.split(" ")[1])
    elif concole == "/photo":
        driver.save_screenshot("screen.png")
    elif "/proxy" in concole:
        if concole.split(" ")[1] == "off":
            driver.disable_proxy()
        elif concole.split(" ")[1] == "on":
            pass
